import { View, Text } from 'react-native'
import React from 'react'

export default function Search() {
  return (
    <View>
      <Text>Search</Text>
    </View>
  )
}