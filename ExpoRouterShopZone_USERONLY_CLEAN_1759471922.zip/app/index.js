import { useEffect } from "react";
import { useRouter } from "expo-router";
export default function Page() {
  const router = useRouter();
  useEffect(() => { try { router.replace("/(userTabs)"); } catch { router.push("/(userTabs)"); } }, []);
  return null;
}
