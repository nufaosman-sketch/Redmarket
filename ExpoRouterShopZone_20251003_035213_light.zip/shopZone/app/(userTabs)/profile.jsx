import { StyleSheet, Text, View } from 'react-native'
import React from 'react'
import ProfileScreen from '../ProfileScreen/ProfileScreen'

const profile = () => {
  return <ProfileScreen/>
}

export default profile

const styles = StyleSheet.create({})