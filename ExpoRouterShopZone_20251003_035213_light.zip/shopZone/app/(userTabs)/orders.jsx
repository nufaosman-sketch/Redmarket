import { StyleSheet, Text, View } from 'react-native'
import React from 'react'

const orders = () => {
  return (
    <View>
      <Text>orders</Text>
    </View>
  )
}

export default orders

const styles = StyleSheet.create({})